﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab_11
{
    public partial class Lab_11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (fileResume.HasFile)
            {
                try
                {
                    string fileName = Path.GetFileName(fileResume.PostedFile.FileName);
                    string filePath = Server.MapPath("~/Resumes/") + fileName;
                    fileResume.SaveAs(filePath);

                    // Save the form data to a database or process it as needed
                    // For simplicity, displaying a success message
                    lblMessage.Text = "Application submitted successfully!";
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error: " + ex.Message;
                }
            }
            else
            {
                lblMessage.Text = "Please upload your resume.";
            }
        }

    }
}